﻿namespace ACEAutomationProcesses.Database
{
    class ChildrenModel
    {
        public string Name { get; set; }
        public long DataId { get; set; }
        public int Subtype { get; set; }
    }
}
