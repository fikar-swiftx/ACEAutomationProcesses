﻿namespace ACEAutomationProcesses.Database
{
    class AgencyModel
    {
        public long HrmsPrcCode { get; set; }
        public string HrmsDescription { get; set; }
        public string VoicesAgencyCode { get; set; }
        public string VoicesAgencyName { get; set; }
        public string HrVital { get; set; }
        public string DbthEpFile { get; set; }
        public string AgencySource { get; set; }
    }
}
