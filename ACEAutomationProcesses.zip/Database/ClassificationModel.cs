﻿namespace ACEAutomationProcesses.Database
{
    class ClassificationModel
    {
        public long ClassId { get; set; }
        public string ClassName { get; set; }
    }
}
