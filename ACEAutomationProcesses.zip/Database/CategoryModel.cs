﻿namespace ACEAutomationProcesses.Database
{
    class CategoryModel
    {
        public long CatId { get; set; }
        public string CatName { get; set; }
        public string AttrName { get; set; }
        public string AttrRegion { get; set; }

    }
}
