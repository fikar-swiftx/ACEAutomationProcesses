﻿namespace ACEAutomationProcesses.Database
{
    class FolderAliasModel
    {
        public string FolderName { get; set; }
        public string Alias { get; set; }
        public int Level { get; set; }
        public string ExtraPermission { get; set; }
    }
}
