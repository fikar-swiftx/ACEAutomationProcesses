﻿namespace ACEAutomationProcesses.Model.CSV
{
    class ExitCsv
    {
        public string ProcessIndicator { get; set; }
        public string NRIC { get; set; }
        public string Name { get; set; }
        public string Agency { get; set; }
        public string CurrentPRCCode { get; set; }
        public string DivisionalStatus { get; set; }
        public string EffectiveDate { get; set; }
    }
}
