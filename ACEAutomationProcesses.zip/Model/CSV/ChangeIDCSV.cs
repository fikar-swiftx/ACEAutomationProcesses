﻿namespace ACEAutomationProcesses.Model.CSV
{
    class ChangeIdcsv
    {

        public string ProcessIndicator { get; set; }
        public string NRIC { get; set; }
        public string FIN { get; set; }
        public string EffectiveDate { get; set; }
        public string Agency { get; set; }
    }
}
