﻿namespace ACEAutomationProcesses.Model
{
    class SecondmentScenario
    {
        public string ProcessIndicator { get; set; }
        public long Seq { get; set; }
        public string Id { get; set; }
        public string NewBorrowingAgency { get; set; }
        public string CurrentPrcCode { get; set; }
        public long FormId { get; set; }
        public string ProcessStatus { get; set; }
        public string ParentAgency { get; set; }
    }
}
